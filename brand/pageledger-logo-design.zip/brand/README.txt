PageLedger — Logo & Brand Assets
================================

Concept:  "the tallied page" — a dog-eared page carrying a five-bar tally,
          fusing the two ideas the package is built on: the PAGE as the
          canonical unit, and the LEDGER that counts it.
Type:     Archivo 700 (evokes "archive"). Wordmark = page (ink) + ledger (brick).

COLORS
------
Ink            #1F1B16   (outline, "page" wordmark)
Brick (accent) #B0432F   ("ledger" wordmark, tally)
Paper          #F7F4ED   (light background)
Fold           #E7E0D0   (folded-corner fill)
Dark ground    #211D17   (reversed background, app tile)
Cream          #F2ECDD   (mark on dark)
Warm accent    #D98C72   (tally on dark)
Alt accents    #3E6B4F green · #A9762A ochre · #3C5A7A slate  (explored alternates)

FILES
-----
open index.html in a browser to preview everything on a transparency checkerboard.

svg/   scalable, self-contained (font embedded) — best for web, print, scaling
  pageledger-icon.svg              icon, full color
  pageledger-icon-reversed.svg     icon for dark backgrounds
  pageledger-icon-knockout.svg     single-color white icon
  favicon.svg                      scalable favicon
  pageledger-app-tile.svg          rounded dark app tile
  pageledger-wordmark.svg          wordmark only
  pageledger-wordmark-reversed.svg wordmark for dark backgrounds
  pageledger-lockup-horizontal.svg          icon + wordmark (primary)
  pageledger-lockup-horizontal-reversed.svg primary, for dark backgrounds
  pageledger-lockup-stacked.svg             icon above wordmark

png/   transparent raster (except app tile, which has its own ground)
  pageledger-icon-256/512/1024.png           (1024 = master)
  pageledger-icon-reversed-512/1024.png
  pageledger-icon-knockout-512/1024.png
  favicon-16/32/48/64.png                    (16 & 32 use a simplified tally)
  pageledger-app-tile-512/1024.png
  pageledger-wordmark.png / -reversed.png
  pageledger-lockup-horizontal.png / -reversed.png
  pageledger-lockup-stacked.png

fonts/
  Archivo-700.woff2   the exact font used (subset). Also embedded inside every SVG.

USAGE
-----
- Prefer SVG wherever it is supported; PNGs are for fixed-size/raster contexts.
- Clear space: keep free space around the lockup >= the height of the folded corner.
- Min size: below ~24 px use favicon-16 / favicon-32 (full mark loses the tally small).
- On dark or busy backgrounds use the reversed (color) or knockout (white) art.
- Do not recolor the mark outside the palette above, rotate it, or add effects.

Font: Archivo, SIL Open Font License 1.1 (https://fonts.google.com/specimen/Archivo).
Marks generated for the PageLedger project.
